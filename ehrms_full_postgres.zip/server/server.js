
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../frontend')));

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Initialize tables if not exist
async function initDb(){
  await pool.query(`
  CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS employees (
    id TEXT PRIMARY KEY,
    name TEXT,
    dept TEXT,
    role TEXT,
    grade TEXT,
    salary INTEGER,
    leave_balance INTEGER
  );
  CREATE TABLE IF NOT EXISTS payrolls (
    month TEXT PRIMARY KEY,
    items JSONB
  );
  CREATE TABLE IF NOT EXISTS promotions (
    id TEXT PRIMARY KEY,
    emp TEXT,
    newGrade TEXT,
    status TEXT,
    created TIMESTAMP
  );
  `);
}
initDb().catch(err=>console.error('initDb error',err));

// helper auth
function generateToken(username){ return jwt.sign({ username }, JWT_SECRET, { expiresIn: '8h' }); }
async function verifyTokenMiddleware(req,res,next){
  const auth = req.headers['authorization']; if(!auth) return res.status(401).json({error:'missing token'});
  const m = auth.match(/^Bearer\s+(.+)$/); if(!m) return res.status(401).json({error:'invalid token'});
  try{ const payload = jwt.verify(m[1], JWT_SECRET); req.user = payload; next(); }catch(e){ return res.status(401).json({error:'invalid or expired token'}); }
}

// Auth endpoints
app.post('/api/auth/register', async (req,res)=>{
  const { username, password } = req.body; if(!username||!password) return res.status(400).json({error:'username & password required'});
  const exist = await pool.query('SELECT username FROM users WHERE username=$1',[username]);
  if(exist.rows.length>0) return res.status(400).json({error:'user exists'});
  const hash = bcrypt.hashSync(password,10);
  await pool.query('INSERT INTO users (username,password_hash) VALUES ($1,$2)',[username,hash]);
  res.json({ok:true});
});

app.post('/api/auth/login', async (req,res)=>{
  const { username, password } = req.body; if(!username||!password) return res.status(400).json({error:'username & password required'});
  const r = await pool.query('SELECT * FROM users WHERE username=$1',[username]);
  if(r.rows.length===0) return res.status(400).json({error:'invalid credentials'});
  const user = r.rows[0];
  const ok = bcrypt.compareSync(password, user.password_hash);
  if(!ok) return res.status(400).json({error:'invalid credentials'});
  const token = generateToken(username);
  res.json({ token });
});

// Seed demo data (creates admin/admin123)
app.post('/api/seed', async (req,res)=>{
  try{
    const admin = await pool.query('SELECT username FROM users WHERE username=$1',['admin']);
    if(admin.rows.length===0){
      const hash = bcrypt.hashSync('admin123',10);
      await pool.query('INSERT INTO users (username,password_hash) VALUES ($1,$2)',['admin',hash]);
    }
    // seed employees
    await pool.query('DELETE FROM employees');
    await pool.query("INSERT INTO employees (id,name,dept,role,grade,salary,leave_balance) VALUES ($1,$2,$3,$4,$5,$6,$7)",['EMP001','Asha Verma','Education','Primary Teacher','P2',54000,18]);
    await pool.query("INSERT INTO employees (id,name,dept,role,grade,salary,leave_balance) VALUES ($1,$2,$3,$4,$5,$6,$7)",['EMP002','Ramesh Kumar','Health','Staff Nurse','N1',47000,12]);
    await pool.query("INSERT INTO employees (id,name,dept,role,grade,salary,leave_balance) VALUES ($1,$2,$3,$4,$5,$6,$7)",['EMP003','Sangeeta Singh','Revenue','Clerk','C3',38000,8]);
    // seed payroll
    const items = [{emp:'EMP001',gross:62000,ded:8000,net:54000},{emp:'EMP002',gross:54000,ded:7000,net:47000},{emp:'EMP003',gross:42000,ded:4000,net:38000}];
    await pool.query('INSERT INTO payrolls (month,items) VALUES ($1,$2) ON CONFLICT (month) DO UPDATE SET items = EXCLUDED.items',['2025-10', JSON.stringify(items)]);
    res.json({ok:true, msg:'seeded, admin/admin123'});
  }catch(e){ console.error(e); res.status(500).json({error:'seed failed'}); }
});

// Stats
app.get('/api/stats', async (req,res)=>{
  const employees = (await pool.query('SELECT count(*) FROM employees')).rows[0].count;
  const payrolls = (await pool.query('SELECT count(*) FROM payrolls')).rows[0].count;
  const promotions = (await pool.query('SELECT count(*) FROM promotions')).rows[0].count;
  res.json({ employees: Number(employees), payrolls: Number(payrolls), promotions: Number(promotions) });
});

// Employees CRUD
app.get('/api/employees', async (req,res)=>{
  const r = await pool.query('SELECT * FROM employees ORDER BY id');
  res.json(r.rows);
});
app.get('/api/employees/:id', async (req,res)=>{
  const r = await pool.query('SELECT * FROM employees WHERE id=$1',[req.params.id]);
  if(r.rows.length===0) return res.status(404).json({error:'not found'});
  res.json(r.rows[0]);
});
app.post('/api/employees', verifyTokenMiddleware, async (req,res)=>{
  const e = req.body; if(!e.id) return res.status(400).json({error:'id required'});
  await pool.query('INSERT INTO employees (id,name,dept,role,grade,salary,leave_balance) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, dept=EXCLUDED.dept, role=EXCLUDED.role, grade=EXCLUDED.grade, salary=EXCLUDED.salary, leave_balance=EXCLUDED.leave_balance',[e.id,e.name,e.dept,e.role,e.grade,e.salary,e.leave_balance||0]);
  res.json({ok:true});
});
app.put('/api/employees/:id', verifyTokenMiddleware, async (req,res)=>{
  const body = req.body;
  await pool.query('UPDATE employees SET name=$1, dept=$2, role=$3, grade=$4, salary=$5, leave_balance=$6 WHERE id=$7',[body.name,body.dept,body.role,body.grade,body.salary,body.leave_balance,req.params.id]);
  res.json({ok:true});
});
app.delete('/api/employees/:id', verifyTokenMiddleware, async (req,res)=>{ await pool.query('DELETE FROM employees WHERE id=$1',[req.params.id]); res.json({ok:true}); });

// Payrolls
app.get('/api/payrolls', async (req,res)=>{ const r = await pool.query('SELECT month, items FROM payrolls ORDER BY month DESC'); res.json(r.rows.map(r=>({month:r.month, items:r.items}))); });
app.get('/api/payrolls/:month', async (req,res)=>{ const r = await pool.query('SELECT items FROM payrolls WHERE month=$1',[req.params.month]); if(r.rows.length===0) return res.status(404).json({error:'not found'}); res.json({month:req.params.month, items:r.rows[0].items}); });
app.post('/api/payrolls', verifyTokenMiddleware, async (req,res)=>{ const { month } = req.body; if(!month) return res.status(400).json({error:'month required'}); const emps = (await pool.query('SELECT * FROM employees')).rows; const items = emps.map(e=>{ const gross = Math.round(e.salary*1.10); const ded = Math.round(gross*0.12); return { emp: e.id, gross, ded, net: gross-ded }; }); await pool.query('INSERT INTO payrolls (month,items) VALUES ($1,$2) ON CONFLICT (month) DO UPDATE SET items=EXCLUDED.items',[month, JSON.stringify(items)]); res.json({ok:true}); });
app.delete('/api/payrolls/:month', verifyTokenMiddleware, async (req,res)=>{ await pool.query('DELETE FROM payrolls WHERE month=$1',[req.params.month]); res.json({ok:true}); });

// Promotions
app.get('/api/promotions', async (req,res)=>{ const r = await pool.query('SELECT * FROM promotions ORDER BY created DESC'); const rows = r.rows.map(p=>({ ...p })); // attach name later on front if needed
  res.json(rows); });
app.post('/api/promotions', verifyTokenMiddleware, async (req,res)=>{ const { emp, newGrade } = req.body; if(!emp||!newGrade) return res.status(400).json({error:'emp and newGrade required'}); const id = 'PR' + Math.floor(Math.random()*900000+1000); await pool.query('INSERT INTO promotions (id,emp,newGrade,status,created) VALUES ($1,$2,$3,$4,$5)',[id,emp,newGrade,'Pending',new Date()]); res.json({ok:true}); });
app.put('/api/promotions/:id/approve', verifyTokenMiddleware, async (req,res)=>{ const id = req.params.id; const r = await pool.query('SELECT * FROM promotions WHERE id=$1',[id]); if(r.rows.length===0) return res.status(404).json({error:'not found'}); const promo = r.rows[0]; await pool.query('UPDATE promotions SET status=$1 WHERE id=$2',['Approved',id]); await pool.query('UPDATE employees SET grade=$1 WHERE id=$2',[promo.newgrade,promo.emp]); res.json({ok:true}); });

// Chat endpoint (rule-based + optional OpenAI proxy)
app.post('/api/chat', async (req,res)=>{
  const { text } = req.body;
  if(!text) return res.status(400).json({error:'text required'});
  const empMatch = text.match(/EMP\d{3}/i);
  const emp = empMatch ? (await pool.query('SELECT * FROM employees WHERE id=$1',[empMatch[0].toUpperCase()])).rows[0] : null;
  if(/leave|leave balance/i.test(text)) return res.json({ reply: emp ? `Employee ${emp.name} (${emp.id}) has ${emp.leave_balance} days leave remaining.` : 'Please mention employee id (e.g., EMP001).' });
  if(/salary|salary slip|pay/i.test(text)){
    if(emp){
      const rows = (await pool.query('SELECT month, items FROM payrolls ORDER BY month DESC')).rows;
      for(const r of rows){
        const it = r.items.find(i=>i.emp===emp.id);
        if(it) return res.json({ reply: `Latest salary for ${emp.name} (${emp.id}) — Month: ${r.month}, Net: ${it.net}` });
      }
      return res.json({ reply: `No payroll found for ${emp.name} (${emp.id}).` });
    }
    return res.json({ reply: 'Please specify employee id, e.g., "Salary slip EMP001".' });
  }
  const OPENAI_KEY = process.env.OPENAI_API_KEY;
  if(OPENAI_KEY){
    try{
      const r = await axios.post('https://api.openai.com/v1/chat/completions',{ model:'gpt-4o-mini', messages:[{role:'system',content:'You are an HR assistant.'},{role:'user',content:text}], max_tokens:300 },{ headers:{ Authorization:`Bearer ${OPENAI_KEY}` } });
      const reply = r.data.choices?.[0]?.message?.content || 'No reply';
      return res.json({ reply });
    }catch(err){ console.error('OpenAI proxy failed', err.message||err); return res.json({ reply: 'Chat proxy failed.' }); }
  }
  res.json({ reply: 'Sorry, I did not understand. Try: "Leave balance EMP001" or "Salary slip EMP002".' });
});

// Serve frontend SPA
app.get('*', (req,res)=> res.sendFile(path.join(__dirname, '../frontend/index.html')));

app.listen(PORT, ()=> console.log('eHRMS full project (Postgres) listening on', PORT));
