
# eHRMS — Full Project (PostgreSQL)

This project contains a fullstack prototype with:
- Frontend: static HTML/CSS/JS (circular UI, animated light-green banner)
- Backend: Express + PostgreSQL with JWT auth, chatbot endpoint, payroll, promotions, employees CRUD

## Quick start (PostgreSQL)

1. Start a PostgreSQL instance (local or Docker). Example docker-compose is included.
2. Set DATABASE_URL env var, for example:
   export DATABASE_URL="postgres://postgres:password@localhost:5432/ehrmsdb"
3. Install and start server:
   cd server
   npm install
   npm start
4. Seed demo data:
   curl -X POST http://localhost:3000/api/seed
5. Open http://localhost:3000

## Docker (Postgres) example
A `docker-compose.yml` is included — run `docker-compose up -d` to start Postgres, then run the server.

## Notes
- For OpenAI-powered chat, set OPENAI_API_KEY in server environment.
- Secure JWT_SECRET before production.
